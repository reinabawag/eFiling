SET foreign_key_checks = 0;
#
# TABLE STRUCTURE FOR: departments
#

DROP TABLE IF EXISTS `departments`;

CREATE TABLE `departments` (
  `deptcode` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`deptcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('100', 'FINANCE', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('110', 'GENERAL ACCOUNTING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('120', 'COST ACCOUNTING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('130', 'TREASURY', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('140', 'CREDIT & COLLECTION', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('150', 'MIS', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('200', 'SALES & MARKETING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('210', 'SALES', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('211', 'SALES\\VisMin', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('220', 'MARKETING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('230', 'SHIPPING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('300', 'MANUFACTURING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('310', 'JOBCON', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('320', 'PPMC', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('321', 'PRODUCT PLANNING & CONTROL', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('322', 'MATERIAL PLANNING & CONTROL', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('330', 'PED', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('331', 'PROCESS ENGINEERING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('332', 'TOOL AND DIE', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('340', 'QAD', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('341', 'QUALITY ASSURANCE', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('342', 'SCRAP MONITORING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('350', 'PEMD', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('351', 'PEMD-MECHANICAL', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('352', 'PEMD-ELECTRICAL', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('353', 'PEMD-BGM/STOCKROOM', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('400', 'PURCHASING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('410', 'SRAP HANDLING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('500', 'HRDD', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('501', 'GENRAL SERVICES/ PERSONNEL', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('600', 'AUDIT', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('700', 'ISO', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('800', 'EXECUTIVE', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('801', 'EXECUTIVE SUPPORT', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('ACC', 'Accounting', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('MKTG', 'Marketing', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('PROD', 'Production', 'ACTIVE');


#
# TABLE STRUCTURE FOR: employees
#

DROP TABLE IF EXISTS `employees`;

CREATE TABLE `employees` (
  `empcode` varchar(10) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `deptcode` varchar(10) NOT NULL,
  `supervisor` bit(1) DEFAULT NULL,
  `depthead` bit(1) DEFAULT NULL,
  `secthead` bit(1) DEFAULT NULL,
  `divhead` bit(1) DEFAULT NULL,
  `is_hr` bit(1) DEFAULT NULL,
  `is_payroll` bit(1) DEFAULT NULL,
  `is_audit` bit(1) DEFAULT NULL,
  `hiredate` date NOT NULL,
  PRIMARY KEY (`empcode`),
  KEY `deptcode` (`deptcode`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`deptcode`) REFERENCES `departments` (`deptcode`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('000564', '$2y$10$9TPPMeXM2AFXnA.EBKaz3Oz6JXyJH4JnH7HhpCf/8eNMWpjPN5kAq', 'MEDES', 'ALFREDO', 'PERSIA', '300', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1964-11-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('003286', '$2y$10$UNwk1VvZr0ObFFiO1WL4IO1btd.VzlQl/oJrR9Z.dzvsT3cFtgr5y', 'JAO', 'DENIS', 'JANEO', '332', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1986-07-08');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('003486', '$2y$10$S0AZg.fatSouOPejsAd3neFeSOb05vWZCMevlA0KF58LKRGW.Piwu', 'COMIA', 'SHEBA', 'SALUDES', '600', '0', '1', '0', '0', '1', NULL, NULL, '1986-12-11');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('003987', '$2y$10$oF5YE47UjbYYcvPa9GqAwOKoqDw4SoG4SbSMWd/0MWOce8.H4iola', 'POON', 'JOEL RAIDIS', 'URIARTE', '320', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1987-02-03');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('004187', '$2y$10$9psGGEFAIpFKwdoBxVbd..EXfTaXBZ/KR/TrahQRpUccmIpL.8M/6', 'PLAZA', 'ALFREDO', 'COLETO', '350', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1987-02-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('004387', '$2y$10$p4VjvNlbMRA81IbmEfY0s.A2rC4opHeuPjiALJ8CFmyCj//3tx2vC', 'REYES', 'MARIE MAGDALENE', 'MONDIGUING', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1987-03-23');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('006188', '$2y$10$yeHhLdnV/.tzhf7vJw0u5O5gEwV.NBGSmhFc83i1HiRTctbHUo0l.', 'ESTEBAL', 'BENJAMIN', 'MORALES', '341', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1988-05-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('006888', '$2y$10$5i93wSIKm3yGtbDhhGNNfORWqtCpsTim3Epi79F6Hfp.lg0zNBloO', 'ROSALES', 'APOLINARIO', 'REY', '322', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1988-08-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('007789', '$2y$10$RKjWa9lpJfXQuwQcysVG3.nbA04Vnx3aqWRSSnhRKVUzrMKjoUHrG', 'CRUZ', 'ROSALINDA', 'GALVEZ', '321', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1989-04-24');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('008589', '$2y$10$QTp5BENdOgZD22Jyqn1.VO7Y0giFDyOdVlEsMAaI1V2j.oxb2xjDO', 'CASTRO', 'NAPOLEON', 'PAGTAMA', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1989-05-30');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('021596', '$2y$10$0XJB1mXJJXGfiJgUSWZENOLRXQ.3nK.KWnhY0jDxZPbD.6B97brda', 'BARLAO', 'VICTOR', 'LIMUN', '332', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1996-05-10');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('022997', '$2y$10$RYKwBQxGEhIhrFqtBCx.I.J8K16ZohGiKmK3CA3upF/GuHUeDVxhS', 'CABACANG', 'HAIDEE', 'NAYA', '130', '0', '1', '0', '0', NULL, NULL, NULL, '1997-07-15');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('023097', '$2y$10$Sl5Xf5pn.FQggLHpoFon8.NP485bm5nu.rUy/lFRA6xuVAK/qiaNa', 'REMPILLO', 'SEAN', 'RAVAGO', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1997-08-16');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('023497', '$2y$10$iefJjBBi6T/bc6jkeb96POGDmE/YKuE7kd0oAg2NqHXgKAay6QRaK', 'ESGUERRA', 'RAYMOND', 'VEDUA', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1997-12-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('023598', '$2y$10$JNI8mAkytgBRolOG.FTu/O8Y0A4r9MS6xIuh2jwpEPM2ZxeE8yAs6', 'GRANADEROS', 'GERONIMA', 'ASUQUE', '110', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1998-01-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('024199', '$2y$10$7RBcbf.AzKKvdihjtR8l0uiMJ0XGc6WD9X6t.QcJ.Sa26W2cqa0Xu', 'NAVARRO', 'ARIEL', 'AMURAO', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1999-05-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('024499', '$2y$10$MQazXcou7ez.4CuwYI1uoOcl719Mo4XS3JZ7te0Zp.x6JP6.sYOB2', 'DELGADO', 'MANUEL', 'CANA', '140', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1999-05-20');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('025396', '$2y$10$9qi/dKzcCUot9UyQte5fs.dwpFgTNG63gCy0j68jZzXMURNjZg71q', 'BALLENA', 'ARLENE', 'BORJA', '110', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1996-05-08');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('025900', '$2y$10$qhjxPOXPHpM.DpTN4rrP5Op2sQRsgPki0amZdH.LJw9g0r5.tUdf.', 'DIOLOLA', 'ROMELYN', 'ROXAS', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2000-06-03');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('026401', '$2y$10$8Zsdb.WfKo6PIS7UVKNXzuKe0GwptUFcNYoec8/WFTmB6u4aVmuX6', 'OCAMPO', 'JIMMY', 'MARFA', '300', '0', '0', '0', '1', NULL, NULL, NULL, '1990-03-16');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027002', '$2y$10$hf.KV6Fgx9GuzO/86v/OluUVJYJKRtbOAjhvKnVF1s28yx7/PBAsS', 'CASTILLO', 'MA. PHOEBE', 'BEDIA', '300', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2002-06-26');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027203', '$2y$10$489zVp07pJVDxxTU1H.IbuBzX6xsxmYb1KaMzKObE.mP8mfjwU5sO', 'FALLECIDO JR.', 'EDGARDO', 'MARIFOSQUE', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2003-10-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027304', '$2y$10$eOzHJ16cm/drZ4h3RPB.uedr5JAWPr.Dk7afcIpkaunLS7mZ3DpOW', 'BACAREZA', 'CECILIA', 'CANALING', '801', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2004-01-05');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027404', '$2y$10$0apmE0hdJGUrZEwaoXv9zOSrckUCYOUf947wmqIyF58iFMmD1eJHi', 'REYES', 'WILFREDO', 'PANGILINAN', '351', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2004-02-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027604', '$2y$10$tmod23tNQCsfNcrjZQQR1eQhvQMoAI2LZwlI/jo6P/61kLqWjTyaG', 'OLIVEROS', 'EDMUNDO', 'VILLANUEVA', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2004-02-23');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027904', '$2y$10$Wc3VW9JJYWbO5pMvo3Ul4OWBgyKzewW1Shi3Pvrwu79yacffXS8zO', 'ROSEUS', 'ANABELLE', 'PO', '140', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2004-06-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('028205', '$2y$10$7jV0WAc3nz6f0JWxX18cqe6sEIsDoLmpfvL1WlQt7Mt1lzt25xbpW', 'ACERIMO', 'JEFFREY', 'ADOFINA', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2005-04-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('028405', '$2y$10$JTApKem6mjyWVWVttn87ZO/n.cPImfgeFVvKz8iNT2butJ6OoFKvG', 'CASANES', 'NOEL', 'BAGUS', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2005-04-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('028905', '$2y$10$dDg1zRhzIBdW9tbkTv87heNYavI7EniI0ZjS3nvg29GHOCFBuxfcm', 'DEL ROSARIO', 'JOEY', 'SABALE', '330', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2005-12-05');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('029606', '$2y$10$CEw9yD7EpO8ysZ84xRqMp.QGg0VfeTBQgSwoOHl6d5N5pBYRL/ZyW', 'CELEBRE', 'EDGAR', 'TUALLA', '100', '0', '0', '0', '1', NULL, NULL, NULL, '2006-08-07');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('029906', '$2y$10$9MQQwSMBKjMMK23EaAGMGOhYzjPMRjowU35gqDWcG6RJCiMk.NGKe', 'EGUIA', 'RHUEL', 'MACALINDONG', '400', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2006-10-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('031307', '$2y$10$VEwFg94LUAk.C7QHLyTUe.7656YuIstCq9ZHz1NVVBX1PsQYL54zq', 'PAJUTAN', 'MELVIRG', 'ROXAS', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2007-03-07');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('031707', '$2y$10$bx6tvgfOLdhR00B1bEzDK.WAvG3M.Gwme9EQUEIq6QUbWC.dpjF3i', 'LIPIO', 'JOSEPHINE', 'ORBILLO', '321', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2007-07-10');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('031807', '$2y$10$IHW0hK7xI8W.F1UMVAcnBuDUN8EU/SrV.DR4GL4ruM3iWk4Fc2VJq', 'ROBLES', 'GLECY', 'VILLAMOR', '321', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2007-07-10');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('032007', '$2y$10$hc3UEHHY/fkeCVyS8BsErOFxRp636IbT8wqdtZoFhZKZHURVqYi/u', 'BAGO', 'MA. VICTORIA', 'DE LEON', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2007-08-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('032407', '$2y$10$k11UyFoCeVF7pgAKJ/LoIO/83xLvj8MlbNTaBeuqaq2iOwNpwbSX2', 'BANNAGAO', 'LAWRENCE ARNEL', 'ACOSTA', '322', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2007-09-24');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('032608', '$2y$10$eVd0h/hQ6N1c4FTEJX5JButjZ9Z8b.1VzCQeycerJJ/WmdUENi3Z6', 'RUAR', 'FLORDELIZA', 'BISCO', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2008-02-18');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('032808', '$2y$10$OHffsuGdvrJpwIWVv.qGle8DK.mMuHxsqLmc2rquwV.cODnS3H.dW', 'ASINAS', 'MARLON', 'DURAN', '150', '1', '0', '0', '0', NULL, NULL, NULL, '2008-02-26');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('034409', '$2y$10$KWDBYGHTNzaP2g8MgTmCQ./0OODfDLVXXgh/cTjeXfvD7Yn5dGSnq', 'LUZANO', 'ROMEL', 'BUGARIN', '351', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2009-04-27');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('034709', '$2y$10$4f9aT1fT06ozvYnEu/tlSO8ZNBl3QUva9GyDYeXZx80QXMUcvH0XK', 'ITLIONG', 'MARK GIL', 'ESTIBAL', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2009-06-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('035009', '$2y$10$E/tkZ5vKNZe1ft/mdxxPxO.GmI14aQATy.yFXP272ISpg/rfXJh8a', 'PANOPIO', 'MELANIE', 'REFIL', '700', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2009-08-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('035109', '$2y$10$D4R3FQB1RBp8ft6uWeR6A.t.3CgIdVhU2VT4nE2c/LM.yB65nLq5.', 'UDARBE', 'MARCEL', 'SALTING', '300', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2009-09-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('035610', '$2y$10$wNh7241I3gPPfBVbmHNsx.3jcvlwTEIOTIxgKa15viWHmFlkubGQC', 'NAQUILA', 'STEMARK', 'PANA', '321', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-02-03');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('035910', '$2y$10$0vjdgFcPdT9Y20QV9CuItuoKG98zb//sXnHVoyXCjxhnIINAQHc4W', 'SAYSON', 'MICHAEL', 'AGATO', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-05-05');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('036611', '$2y$10$kgXAPY9l0F5GEKn7ykHDP.MhxxTUzQjOg5VOR36hgo8B9qFf7D.1K', 'HIFE', 'MARIA ROWENA', 'REYES', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-02-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('039612', '$2y$10$EOphkbSgdFImm5XBW0Ynj.1kbR4PnQwSfrFg1zczMmicRDX88D44y', 'LEYRAN', 'AILENE', 'ROMASANTA', '140', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2012-07-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('039912', '$2y$10$6aSeqm3ZXWmudm.NR9GJreX.6CspGw7OfDTHSsIUVFWoEFBbC75bW', 'BORJA', 'ALFER MARCOS', 'CRISPINO', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2012-11-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('040113', '$2y$10$oDlPGvM0iEGEkOPTUBIeDuMIkOSZd/edDW224WdvriW/1Sps9Ks72', 'MANARIN', 'JEFFEL KURT', 'NAN', '700', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-03-25');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('040613', '$2y$10$wtlJm3sha7cqNQeRN.arj.ZrA.TIgY9jRjAUMqujmY1FD8eNTa2Zi', 'OLIQUINO', 'ROBERTO', 'PERAS', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('041014', '$2y$10$bzcymrLPzatYVvK2yLA5oOLz1Wvr1dVO/UvDIzc2ETfye6oV9DzGK', 'EVANGELISTA', 'JESSA', 'APOR', '140', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-09-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('041214', '$2y$10$HuSh9EI.qSjbdAsmL/wUH.n0W3asY7MMdWfUCF71pgvnpYfUhxHdm', 'MOLINA', 'MARIA PAMELA', 'CAIRO', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-03-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('042214', '$2y$10$XhA6hMHVOve1mN/7.mnR..nv1Irep7DLzweEBCr3sCbacm9ayTU0W', 'SAQUIBAL', 'ARIES VANN', 'RETUYA', '600', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-06-23');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('042515', '$2y$10$wynIA.Bgc/JceIRvMDJkZOCf1HHog2ltooI0HfhShFG/omKdin14C', 'EBARITA', 'JUN ALBERT', 'CORILLA', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-02-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('042615', '$2y$10$A.T5YBEcRPBOimlS15UqLOsQbC24AINEFgpvGIsE9etuou76qeOCm', 'HERNANDEZ', 'CHRISTIAN', 'CAO', '332', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-02-18');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('042715', '$2y$10$YAk7NznjSS7Okp5AGTA4t.OFK2LS4xSiMKLZtjYNU3G/boz36Q13O', 'RAVANA', 'GAYLORD', 'CAMACHO', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-03-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('042815', '$2y$10$pXO2/CcGudV9/RCN3dLV.erAK0XWQwENxJTR9WPC1lmvRA0u7wBQu', 'GARANO', 'MARLON', 'SALVADOR', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-03-05');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('043815', '$2y$10$6v7ttK070DHRvXFmNg4mbOxlWF3y.mrpMeoj8GmsXP9uOOJF06NRq', 'MANINGO', 'ALEJANDRO', 'CABINGAS', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-10-05');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('043915', '$2y$10$InbQTnUVOS8CJTQ6EUvBae.TpeIZnVITPx.RL4s9yonruWPlHCY02', 'ROXAS JR.', 'FELICITO', 'DIZON', '332', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-10-12');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('044216', '$2y$10$9xbAHSnm/wdZTlc2YT5yKeQ9Ou179qEs69C1W6PlhLyQ9UEuSe..O', 'ZABALA', 'KENNETH', 'TORRES', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045016', '$2y$10$JDXp8Y/KnWpU.V3YbAQeyOD1rcwi.cB1cJvyMCdBNDPSlN0FWyT6i', 'CERRUDO', 'CHARMAINE', 'LAGMAN', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-06-20');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045116', '$2y$10$AanCSy8HzjA1vpsQ4L/EqeC9YxwVu2G4ldXfKzO.jCGS5VxkYyb6.', 'CRUZ', 'ELEANORE', 'BANGGA', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-06-22');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045216', '$2y$10$F43buET6pqpOjZKP7B8kXeBwOfQ31sgCz/HJDnQWBfcP0mvU9kZty', 'CELIS', 'MARIDEL', 'VALENCIA', '322', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-07-12');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045316', '$2y$10$0VQKvplTXk1TDzVn2LmDWOu0spr4zUD/oiEpIIy3zIwCf.kllVoFO', 'DE JESUS', 'FERLYN', 'BALICUATRO', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-07-14');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045416', '$2y$10$k.BglXtwGZ2JktcbLYIMsujm5HsAignyszdLMwbNc/PJ2zDCc0GUa', 'AMION', 'GLACESARY', 'EMBILE', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-09-13');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045516', '$2y$10$NLKKzpqMahyG9rWsqGknfO..3oaBjzVaWm2VxF/VTLQlrcanazRci', 'PEREZ', 'MARCH ROSE SHELL', 'PANES', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-09-13');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046016', '$2y$10$KCG4m1LWhYL3eDrmrHRjAOF9/yrPnZxtdrt7L/2ctyA95He.HhdnW', 'JAMORALIN', 'ANELE', 'BAUTISTA', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-11-21');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046217', '$2y$10$PmD7HxJuS.G.3G4APuY3zuBBzr9VSu9Ep3uEVEFH1LcNUWzJco36K', 'RED', 'REYNANTE', 'PETILLA', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-01-16');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046417', '$2y$10$PlgZwoobonIl73nnQh0PzO70ZYkmGC8janAAiaV9qi5YiCMlc3xYS', 'ABAWAG', 'REINHARD CIRE', 'ESCOBAR', '150', '0', '1', '0', '0', NULL, NULL, NULL, '2017-03-13');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046617', '$2y$10$iVB93IWNXPRKQqKBNmg5/O3CS971egvPQ73IL/7p5FtRb5AwlOX32', 'MANDAL', 'MV LEBERTY', 'PAMOLERAS', '100', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-03-13');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046717', '$2y$10$13bfPq6PZAx99YYdwtL3puzl1tjse8m/0RvYdhUQTict7JPIzVLzC', 'TOBIAS', 'EGAN', 'ODICTA', '600', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-03-23');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046817', '$2y$10$RgKLQzpQYtz25fEWtkqj3elLHPYmrnIG2h.7PCTfcbHT1.zwJbn1S', 'MALLETE', 'MONICA', 'BALDERAS', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-04-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047017', '$2y$10$it3dsczw8m5mZ25voe4zL.JZlOP7K.pbXtQXtnu0Zajyl3V2OV..2', 'RIVERA', 'MARK ANGELO', 'PENANO', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-04-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047117', '$2y$10$EvxU9waqwzNgVG1YcJuN7e6OlPAfgrethT4OhW2qJJMXvT5FnkGLO', 'CRISTAL JR.', 'CIPRIANO', 'DILIG', '332', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-05-29');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047317', '$2y$10$eVthvMYYnXCAeCS7ytiO8.Wkc.LlGhc3B4DE/LF8SOhaXht8AM61u', 'ABALIN JR.', 'REYNALDO', 'LUCERO', '352', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-07-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047417', '$2y$10$ZrKnxN8MSaA9bdPtqeVcsOPprK21hjAYNRL.2vsAARIXMBA1IDEzm', 'BORBANO', 'LIEZEL', 'GARCIA', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-07-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047517', '$2y$10$ugc0lIPsEeOKpoy5HZRmkuUhlFAE159GxEgGfUlBercOdkKXEkuZm', 'DINGLE', 'MAYLYN', 'ARABACA', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-08-14');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047617', '$2y$10$pVzkGivzSCXlOmQlQXXAx.Lc69tKBe0l6xHSq9yJJoDKkccQCC0.i', 'CASUGA', 'MAY ANN', 'OBIANO', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-08-14');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047817', '$2y$10$NHROxh.vmrRkRWR4C5wXJOl9gCLY7u2rdluxufg7hziM83SpPXKze', 'VILLAHERMOSA', 'JASMIN', 'REYES', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-11-22');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048018', '$2y$10$9ODXjPcXzzSoKxk2nxDUs.Yibh4ZzHg0Xl6UlT1l3YBk9qA.giAke', 'AGO', 'OLIVE COLEEN', 'DONATO', '400', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-02-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048118', '$2y$10$o1.AkV0hxh7Ite1Xa8HJZuBdXbrfjbb5/GY05eL6nOdYwRR1Eqw5S', 'AGUILON', 'NOEL', 'DE LOS REYES', '321', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-02-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048218', '$2y$10$JBNuZXjnvi3pM9bRoDbQdeU9iOx4aLMplFOPC6NbcLBvAk7IPJBs.', 'BATALON', 'EDGAR', 'INSO', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-02-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048318', '$2y$10$ZdQzx24RVwecCSDntDzUiuWX28S5evKRQ4s.sCbVEvBSwA.tHOIAu', 'PANGANTIHON', 'MARYJANE', 'ALLIC', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-02-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048618', '$2y$10$i8rWiGNX7c6nAh4K3Wu4leuZ3yorCJaEfjVRNz.k/ocLpOpSdZdm6', 'MUENA', 'ROLANDO JR.', 'BUENAVISTA', '140', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-04-10');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048818', '$2y$10$RCScz9PE4.XliYjPFLa3W.9eghFanAbKrtdUuYs2PNoNAfO34vG9G', 'LEGACION', 'MARIE VIANNEY', 'LIBRANDO', '600', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-06-11');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048918', '$2y$10$fwD0SuJ2qad/QU3MNNZGtOaLrQqMiOy2sAixcN1zqPMY9BNMkioAC', 'MANALO', 'RONALD', 'CUENCA', '130', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-06-21');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('049018', '$2y$10$rJH0d7XrczjVXlzy/EsgtO47CfX4zvsQz5SbP1PKe.gerDAogm3hG', 'FELIZARDO', 'ALVIN', 'ABOT', '352', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-06-21');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('049118', '$2y$10$W/A5F/zBLA53139d.jeYhugph6jnNs0MEruCU8yjk89YxlyxsXO4y', 'MANGONON', 'LEA EDELMA', 'STA MARIA', '500', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-09');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('049418', '$2y$10$ySoy/yQeNPfPRmMwYBFrv.7hYK3oidRR62x59BM7Wa1KN1RBtBMvq', 'HERNANDEZ', 'JENNIFER', 'SANCHEZ', '500', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-11-16');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('049719', '$2y$10$qXCJL3QPbFOCoW/0F29GFOPOh1MbFUaQYHr/2sbXg/1wFni8VpZg6', 'OLLET', 'CATHLEEN', 'CUEVA', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-18');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('049919', '$2y$10$Ge9vOn5nxjsZR8jOiSFitOqMyIb6CyJj/MNiA3u.9BDWx98bII9be', 'HONRADE', 'RICHARD ANTHONY', 'PONAN', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-09-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050019', '$2y$10$8CIXqa.NsrsnkaibP8CAeOmzUgvJluRobeAgLyboD75YesIRAaxEG', 'GO,  JR.', 'JOAQUIN', 'LIM', '211', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-09-23');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050119', '$2y$10$A31X4c9tPblNfvz2KgEjeO.lDJoAFIXUxb3AQmgaPKjgr.6kEE8pW', 'GALIPOSO', 'ROEL', 'PONTRIAS', '211', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-14');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050219', '$2y$10$KtDWN.NyI1HPYG9PHK7PQuMkk.USX1G/5gzZjcfiVTdLZ.93Ilw2.', 'ONG', 'SOCORRO', 'ROPELOS', '500', '0', '1', '0', '0', NULL, NULL, NULL, '2019-10-15');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050419', '$2y$10$3NYDwno7QgUZP23zLE7VkOfd9qHwcM9SntPUXXuf1vqyocRp.IvVS', 'LIBED', 'ARNOLD', 'NOVAL', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-14');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050519', '$2y$10$GC8PSdrSibJ83bzGjXNJHuoNhGMwdTpVkESO4CtlXQ/5CkhPnTo2e', 'MARCELO', 'ANNA LIZZA', 'ARGANA', '700', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-12-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050620', '$2y$10$G4xu98Gyv5dXAE.coWNdnujO3aioUcKREkCUI1J/rAY7yMFK1b2NK', 'BREVA', 'JENNETTE', 'GAN', '130', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-01-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050720', '$2y$10$2P5kbiaEUGBIfKtR29qNOO0HlgdkNCJ.E5yHMG25n4Fcjhjx4tI3a', 'ROGEL', 'CHRISTIAN', 'PADOC', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-01-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050820', '$2y$10$mPQMwSs1fSAloSmQhsM9Z.gXjYQsEtlbMt3nQrn8FgMM6Hql.hI3.', 'VARGAS', 'VICTOR JOSEPH', 'MAG-ISA', '400', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-01-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050920', '$2y$10$19B1a5XeN52ntLwfSI87kelEL6OErXRbZuLaV77eSnNNm7mFTILoS', 'SALE', 'JOENARD', 'CUSTODIO', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-03');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051120', '$2y$10$mmHv0xnM0EmDc5qKOMjwv.79H53CUz8Gr14Eg5iFYfK/rR/tiXkQO', 'CARMEN', 'JENEROSE', 'EMA', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051320', '$2y$10$41jHkzDvEgEU1TDfyZtzEOEWdgi/v.qGmdw0CiwZvTS1grx80Ei8W', 'CARIAGA', 'EVANGELINE', 'SUING', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-16');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051420', '$2y$10$a129BBzpYYQ6TYa29CTgveWlyEWYQ4943ImL0CYCST0Q1rLrCPHdG', 'DE GUZMAN', 'ALVIN', 'OLILA', '351', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051520', '$2y$10$Dgc6gTgBGzXRPtw6Pu9pDOAm.qgv3vYsdOhWptBToOvRS3bAZ3F9i', 'FLORES JR', 'PRISCILO FABIAN', 'REYES DE LOS', '352', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051620', '$2y$10$uXtlREbCZzHB2j2hnpBQEOQ6n/6G.YZA6BRGJ9wRDs2XRvqerYNrG', 'PULLON', 'JAN ADRIAN', 'DELA CRUZ', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-10-28');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051720', '$2y$10$6knrNWxnFcZrGJ0u/yrIpOu/JRXDSIeYtPp/Ope79elL0Ie7zMGfa', 'VILLANUEVA', 'ALLEN', 'DEQUINA', '353', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-10-28');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051821', '$2y$10$MZrlVgFsWGoYkhGXmo1MnuOGtpMSbRK5DyQKLTPPifRbCwpNGfsKO', 'BALLESTEROS', 'MARTHA JORGIANNA', 'LUCES', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051921', '$2y$10$tDZismGRBBF8NdWzYAdPluLSBytQKaXAF7u4LtrNCO7RB.m8ipHOW', 'CARANGUIAN', 'ARNOLD', 'DAYAG', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-15');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('052021', '$2y$10$pPL7oTwiZ4axe/myMS7Efet2E8GoEPPZl/EkAO0iwK.uqJP408Q66', 'ONG', 'JOVITO', 'CATAHAY', '200', '0', '0', '0', '1', NULL, NULL, NULL, '2021-02-15');


#
# TABLE STRUCTURE FOR: leaves
#

DROP TABLE IF EXISTS `leaves`;

CREATE TABLE `leaves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empcode` varchar(6) NOT NULL,
  `name` varchar(65) NOT NULL,
  `date_filed` date NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `pay` varchar(65) NOT NULL,
  `type` varchar(65) NOT NULL,
  `reason` text NOT NULL,
  `recommended_by` varchar(6) DEFAULT NULL,
  `approved_by` varchar(6) DEFAULT NULL,
  `rec_status` tinyint(1) NOT NULL,
  `appr_status` tinyint(1) NOT NULL,
  `status` varchar(10) DEFAULT 'PENDING',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `leaves` (`id`, `empcode`, `name`, `date_filed`, `date_start`, `date_end`, `pay`, `type`, `reason`, `recommended_by`, `approved_by`, `rec_status`, `appr_status`, `status`) VALUES (1, '046417', 'ABAWAG, REINHARD CIRE ESCOBAR', '2021-04-09', '2021-04-09', '2021-04-09', 'without pay', 'Paternity', 'sa', '046417', '046417', 1, 0, 'PENDING');
INSERT INTO `leaves` (`id`, `empcode`, `name`, `date_filed`, `date_start`, `date_end`, `pay`, `type`, `reason`, `recommended_by`, `approved_by`, `rec_status`, `appr_status`, `status`) VALUES (2, '046417', 'ABAWAG, REINHARD CIRE ESCOBAR', '2021-04-09', '2021-04-15', '2021-04-15', 'without pay', 'Vacation', 'Sa bahay lang', '046417', '029606', 1, 1, 'APPROVED');
INSERT INTO `leaves` (`id`, `empcode`, `name`, `date_filed`, `date_start`, `date_end`, `pay`, `type`, `reason`, `recommended_by`, `approved_by`, `rec_status`, `appr_status`, `status`) VALUES (3, '050620', 'BREVA, JENNETTE GAN', '2021-04-23', '2021-04-30', '2021-05-06', 'with pay', 'Vacation', 'PAHINGA ', '022997', '029606', 0, 0, 'PENDING');
INSERT INTO `leaves` (`id`, `empcode`, `name`, `date_filed`, `date_start`, `date_end`, `pay`, `type`, `reason`, `recommended_by`, `approved_by`, `rec_status`, `appr_status`, `status`) VALUES (4, '042214', 'SAQUIBAL, ARIES VANN RETUYA', '2021-04-23', '2021-04-23', '2021-04-23', 'with pay', 'Vacation', 'sa', '003486', '', 1, 1, 'APPROVED');
INSERT INTO `leaves` (`id`, `empcode`, `name`, `date_filed`, `date_start`, `date_end`, `pay`, `type`, `reason`, `recommended_by`, `approved_by`, `rec_status`, `appr_status`, `status`) VALUES (5, '042214', 'SAQUIBAL, ARIES VANN RETUYA', '2021-04-23', '2021-04-30', '2021-04-30', 'with pay', 'Vacation', 'sa', '003486', '', 0, 0, 'PENDING');
INSERT INTO `leaves` (`id`, `empcode`, `name`, `date_filed`, `date_start`, `date_end`, `pay`, `type`, `reason`, `recommended_by`, `approved_by`, `rec_status`, `appr_status`, `status`) VALUES (6, '042214', 'SAQUIBAL, ARIES VANN RETUYA', '2021-04-23', '2021-04-24', '2021-04-24', 'with pay', 'Vacation', 'sa', '003486', NULL, 0, 0, 'PENDING');


#
# TABLE STRUCTURE FOR: overtimes
#

DROP TABLE IF EXISTS `overtimes`;

CREATE TABLE `overtimes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empcode` varchar(10) NOT NULL,
  `deptcode` varchar(10) NOT NULL,
  `date_filed` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `hrs` double NOT NULL,
  `reason` text NOT NULL,
  `rec_by` varchar(10) DEFAULT NULL,
  `appr_by` varchar(10) DEFAULT NULL,
  `rec_status` bit(1) DEFAULT NULL,
  `appr_status` bit(1) DEFAULT NULL,
  `status` varchar(10) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `appr_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `overtimes` (`id`, `empcode`, `deptcode`, `date_filed`, `start_time`, `end_time`, `hrs`, `reason`, `rec_by`, `appr_by`, `rec_status`, `appr_status`, `status`, `create_date`, `appr_date`) VALUES (15, '042214', '600', '2021-04-23', '17:54:00', '17:54:00', '0', '', '003486', NULL, '1', '1', 'APPROVED', '2021-04-23 17:54:51', NULL);
INSERT INTO `overtimes` (`id`, `empcode`, `deptcode`, `date_filed`, `start_time`, `end_time`, `hrs`, `reason`, `rec_by`, `appr_by`, `rec_status`, `appr_status`, `status`, `create_date`, `appr_date`) VALUES (16, '046417', '150', '2021-04-23', '18:29:00', '18:29:00', '24', '', '046417', '029606', '1', '1', 'APPROVED', '2021-04-23 18:29:41', NULL);


#
# TABLE STRUCTURE FOR: schedule
#

DROP TABLE IF EXISTS `schedule`;

CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp` varchar(10) NOT NULL,
  `date_filed` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `purpose` varchar(50) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `from_time` varchar(50) NOT NULL,
  `to_time` varchar(50) NOT NULL,
  `reason` text NOT NULL,
  `reliever` varchar(50) NOT NULL,
  `approver` varchar(10) NOT NULL,
  `personnel` varchar(10) DEFAULT NULL,
  `approved` tinyint(1) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'PENDING',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `schedule` (`id`, `emp`, `date_filed`, `purpose`, `from_date`, `to_date`, `from_time`, `to_time`, `reason`, `reliever`, `approver`, `personnel`, `approved`, `status`) VALUES (1, '046417', '2021-04-08 10:51:06', 'WORK FROM HOME', '2021-04-07', '2021-04-09', '2:00 pm to 10:00 pm', '8:00 am to 5:00 pm', 'home quarantine', '', '046417', NULL, 1, 'APPROVED');
INSERT INTO `schedule` (`id`, `emp`, `date_filed`, `purpose`, `from_date`, `to_date`, `from_time`, `to_time`, `reason`, `reliever`, `approver`, `personnel`, `approved`, `status`) VALUES (2, '046417', '2021-04-10 15:19:01', 'CHANGE SHIFT', '2021-04-12', '2021-04-30', '2:00 pm to 10:00 pm', '8:00 am to 5:00 pm', 'Back to normal schedule', '', '046417', NULL, 1, 'APPROVED');
INSERT INTO `schedule` (`id`, `emp`, `date_filed`, `purpose`, `from_date`, `to_date`, `from_time`, `to_time`, `reason`, `reliever`, `approver`, `personnel`, `approved`, `status`) VALUES (3, '042214', '2021-04-23 16:50:39', 'WORK FROM HOME', '2021-04-23', '2021-04-23', '8am', '5pm', 'hello', 'n.a.', '', NULL, 0, 'PENDING');
INSERT INTO `schedule` (`id`, `emp`, `date_filed`, `purpose`, `from_date`, `to_date`, `from_time`, `to_time`, `reason`, `reliever`, `approver`, `personnel`, `approved`, `status`) VALUES (4, '042214', '2021-04-23 16:54:57', 'WORK FROM HOME', '2021-04-23', '2021-04-23', '8am', '8am', 'hello', 'na', '003486', NULL, 1, 'APPROVED');


#
# TABLE STRUCTURE FOR: trail
#

DROP TABLE IF EXISTS `trail`;

CREATE TABLE `trail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `request_id` int(10) NOT NULL,
  `approver_id` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (1, 'OT', 1, '046417', 1, '2021-03-18 17:37:20');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (2, 'OT', 1, '046417', 1, '2021-03-20 17:59:22');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (3, 'OT', 1, '046417', 1, '2021-03-20 17:59:27');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (4, 'OT', 1, '046417', 1, '2021-03-20 17:59:29');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (5, 'OT', 1, '046417', 1, '2021-03-20 17:59:31');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (6, 'OT', 1, '046417', 1, '2021-03-20 17:59:32');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (7, 'OT', 1, '046417', 1, '2021-03-20 17:59:42');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (8, 'OT', 1, '046417', 1, '2021-03-20 17:59:50');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (9, 'OT', 1, '046417', 1, '2021-03-20 18:16:38');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (10, 'OT', 1, '046417', 1, '2021-03-20 18:24:43');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (11, 'OT', 1, '046417', 1, '2021-03-20 18:33:27');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (12, 'OT', 2, '046417', 1, '2021-03-20 18:34:43');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (13, 'OT', 2, '046417', 1, '2021-03-20 18:34:47');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (14, 'OT', 1, '046417', 1, '2021-03-20 18:44:40');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (15, 'OT', 2, '046417', 1, '2021-03-20 18:44:42');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (16, 'OT', 3, '046417', 1, '2021-03-20 18:46:32');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (17, 'OT', 3, '046417', 1, '2021-03-20 18:52:43');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (18, 'OT', 4, '046417', 1, '2021-03-25 21:58:49');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (19, 'OT', 10, '046417', 1, '2021-03-29 14:15:59');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (20, 'OT', 2, '046417', 1, '2021-03-29 14:16:05');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (21, 'OT', 3, '046417', 1, '2021-03-29 14:16:06');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (22, 'OT', 4, '046417', 1, '2021-03-29 14:16:08');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (23, 'OT', 5, '046417', 1, '2021-03-29 14:16:10');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (24, 'OT', 6, '046417', 1, '2021-03-29 14:16:11');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (25, 'OT', 7, '046417', 1, '2021-03-29 14:16:13');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (26, 'OT', 8, '046417', 1, '2021-03-29 14:16:14');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (27, 'OT', 9, '046417', 1, '2021-03-29 14:16:16');
INSERT INTO `trail` (`id`, `type`, `request_id`, `approver_id`, `status`, `date`) VALUES (28, 'OT', 1, '046417', 1, '2021-03-29 14:16:17');


SET foreign_key_checks = 1;
