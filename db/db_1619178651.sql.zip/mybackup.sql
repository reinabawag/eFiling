SET foreign_key_checks = 0;
#
# TABLE STRUCTURE FOR: departments
#

DROP TABLE IF EXISTS `departments`;

CREATE TABLE `departments` (
  `deptcode` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`deptcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('100', 'FINANCE', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('110', 'GENERAL ACCOUNTING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('120', 'COST ACCOUNTING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('130', 'TREASURY', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('140', 'CREDIT & COLLECTION', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('150', 'MIS', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('200', 'SALES & MARKETING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('210', 'SALES', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('211', 'SALES\\VisMin', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('220', 'MARKETING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('230', 'SHIPPING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('300', 'MANUFACTURING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('310', 'JOBCON', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('320', 'PPMC', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('321', 'PRODUCT PLANNING & CONTROL', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('322', 'MATERIAL PLANNING & CONTROL', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('330', 'PED', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('331', 'PROCESS ENGINEERING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('332', 'TOOL AND DIE', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('340', 'QAD', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('341', 'QUALITY ASSURANCE', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('342', 'SCRAP MONITORING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('350', 'PEMD', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('351', 'PEMD-MECHANICAL', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('352', 'PEMD-ELECTRICAL', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('353', 'PEMD-BGM/STOCKROOM', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('400', 'PURCHASING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('410', 'SRAP HANDLING', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('500', 'HRDD', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('501', 'GENRAL SERVICES/ PERSONNEL', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('600', 'AUDIT', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('700', 'ISO', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('800', 'EXECUTIVE', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('801', 'EXECUTIVE SUPPORT', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('ACC', 'Accounting', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('MKTG', 'Marketing', 'ACTIVE');
INSERT INTO `departments` (`deptcode`, `name`, `status`) VALUES ('PROD', 'Production', 'ACTIVE');


#
# TABLE STRUCTURE FOR: employees
#

DROP TABLE IF EXISTS `employees`;

CREATE TABLE `employees` (
  `empcode` varchar(10) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `deptcode` varchar(10) NOT NULL,
  `supervisor` bit(1) DEFAULT NULL,
  `depthead` bit(1) DEFAULT NULL,
  `secthead` bit(1) DEFAULT NULL,
  `divhead` bit(1) DEFAULT NULL,
  `is_hr` bit(1) DEFAULT NULL,
  `is_payroll` bit(1) DEFAULT NULL,
  `is_audit` bit(1) DEFAULT NULL,
  `hiredate` date NOT NULL,
  PRIMARY KEY (`empcode`),
  KEY `deptcode` (`deptcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('000564', '$2y$10$brwgmdvI7Y.ehRvzcTDkju/u9OjhRSPBDJ2N9wSnTGCeORkcdufBS', 'MEDES', 'ALFREDO', 'PERSIA', '300', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1964-11-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('003286', '$2y$10$/hRR5AglpCxu7crb0p5fj./qJN9AosA0fBf7UH8SSVYkA0CxHIxgC', 'JAO', 'DENIS', 'JANEO', '332', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1986-07-08');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('003486', '$2y$10$DxYOVONBslAM5z0vtZsxLOLAlmJ9jaK99mNCfl9l9vSnTzzhV8kea', 'COMIA', 'SHEBA', 'SALUDES', '600', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1986-12-11');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('003987', '$2y$10$IU/S.9d/uSnRln5V8uyO9eZs2pXj7ufzwO/jHE.5o4ojKv6TTvapK', 'POON', 'JOEL RAIDIS', 'URIARTE', '320', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1987-02-03');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('004187', '$2y$10$uAcvY7fFzW2WRVkZUcoJbu/rOaPhBOJt01rCns6hyJd1zKPNimTPi', 'PLAZA', 'ALFREDO', 'COLETO', '350', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1987-02-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('004387', '$2y$10$SFHHrfAtd.0igPcWyWywseT1SmHkRuoyZ94SVcBBaMKomXMdz10Oy', 'REYES', 'MARIE MAGDALENE', 'MONDIGUING', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1987-03-23');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('006188', '$2y$10$/oHn/beDUcBIMTgRI5uG8Ow5zAuUxwsPyPw//6bJahujEp9rlwakK', 'ESTEBAL', 'BENJAMIN', 'MORALES', '341', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1988-05-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('006888', '$2y$10$8i7qbWMw6TV.7/HzhD11RuEuhmk5xzL4nwLn4GgQGCHzcfdqbEmkC', 'ROSALES', 'APOLINARIO', 'REY', '322', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1988-08-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('007789', '$2y$10$KgBFT25vLzU3JnCEn2mbJeqArkcIxi78V5mmzRaxH83.Gxtgj0yiC', 'CRUZ', 'ROSALINDA', 'GALVEZ', '321', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1989-04-24');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('008589', '$2y$10$lTjQaRGo.ySHEayDBDqXIOBtKnquq4yyQpAM6ZYCahOcsbeV38WLu', 'CASTRO', 'NAPOLEON', 'PAGTAMA', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1989-05-30');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('021596', '$2y$10$EDAkhreeKWU7k.SrZEspx.iHtyHnR08UoSP9NmdBLHP.B2RUWSOnq', 'BARLAO', 'VICTOR', 'LIMUN', '332', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1996-05-10');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('022997', '$2y$10$7LsZ2HUwe3qHOISW7flX1eIVHCl9dojYC3Ol1tUpEbFNCEBPchk2m', 'CABACANG', 'HAIDEE', 'NAYA', '130', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1997-07-15');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('023097', '$2y$10$.whJYUfpQhJUyieUS/T/2.8ZaldOSUwb.tTioVkcJPnYXyBzl7JeG', 'REMPILLO', 'SEAN', 'RAVAGO', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1997-08-16');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('023497', '$2y$10$iUIDIuFLa3dRi1BT92ff4uH5CVT1VZV7.f0N/CsbNDmJCoYe2REY6', 'ESGUERRA', 'RAYMOND', 'VEDUA', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1997-12-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('023598', '$2y$10$RiUWjc4L6I3g/xiNfQz55uqfBlglifqHa8EXOiAnlFqfpgNq7Q2XC', 'GRANADEROS', 'GERONIMA', 'ASUQUE', '110', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1998-01-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('024199', '$2y$10$VHEzIQ2G5vdsUnTnKumod.XqkJbSEJs8bJAG7G5AQAGwc5KKgL/me', 'NAVARRO', 'ARIEL', 'AMURAO', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1999-05-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('024499', '$2y$10$ZkJH7e1Au5RrZL/oIjd2x.UG69qtbFT1CrZwrVY9yHJvAV9o19TiW', 'DELGADO', 'MANUEL', 'CANA', '140', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1999-05-20');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('025396', '$2y$10$IhD.yu.K3lSjZeHnlCNGAeKpnWhFPhEsTX1VlZjhu8pcOvFQRUAc.', 'BALLENA', 'ARLENE', 'BORJA', '110', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1996-05-08');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('025900', '$2y$10$UkrJWk6nR5oyH4poEZ/dPeI5eT1baTYiNClKO40Vtn88e6cZc5MGK', 'DIOLOLA', 'ROMELYN', 'ROXAS', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2000-06-03');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('026401', '$2y$10$ubdSczcDyc4EUEkTj/Pkcujj5qdhjhlo5lN78YA8dmvS724waDiS.', 'OCAMPO', 'JIMMY', 'MARFA', '300', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1990-03-16');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027002', '$2y$10$b4ZO8rdqgR7N2Y.3NNgLd.CGTioa8m.1p2YwbUOBgSrgIoqvD3Tuq', 'CASTILLO', 'MA. PHOEBE', 'BEDIA', '300', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2002-06-26');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027203', '$2y$10$GeeI4rgqJkGbvODpErbNGuDbGugZm2aNGo4xP2iGk5gwDD44gZgOq', 'FALLECIDO JR.', 'EDGARDO', 'MARIFOSQUE', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2003-10-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027304', '$2y$10$mwKzRnoE5bpqoTFyV/YPUegI//xnAmqz7DiGI9FKq.if3IrDch7C2', 'BACAREZA', 'CECILIA', 'CANALING', '801', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2004-01-05');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027404', '$2y$10$LR9bMVDZ9kicc2G27Vgdkeef47L4UKREGGr8d/XC.za2NsYmSgHae', 'REYES', 'WILFREDO', 'PANGILINAN', '351', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2004-02-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027604', '$2y$10$K8byQy69Ld5SeQqlGi8tR.uXG5XV/RMdDNtWg/o2f.t/x2T8dQf1O', 'OLIVEROS', 'EDMUNDO', 'VILLANUEVA', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2004-02-23');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('027904', '$2y$10$hGrvSnBbN8J4Da/W2ICg.uxQzTUFMNMXOkjQ1QAPJPdNNYs2Yc10i', 'ROSEUS', 'ANABELLE', 'PO', '140', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2004-06-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('028205', '$2y$10$pThAkewXpzCxbg5bmCpVv.K2fdunI55RzH2NfwYFrVJalOJdZKrfC', 'ACERIMO', 'JEFFREY', 'ADOFINA', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2005-04-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('028405', '$2y$10$oko5IB43zLu2oN6t96L2Z.XbxZdTWZ34Bw27BQNhVuIDDgbmGaXMi', 'CASANES', 'NOEL', 'BAGUS', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2005-04-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('028905', '$2y$10$OY4/Z.w4FXMvxVRaSTtSMubHW8hqK8DrEmsmbPYV4hU/K5ENC.cYe', 'DEL ROSARIO', 'JOEY', 'SABALE', '330', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2005-12-05');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('029606', '$2y$10$zbqgrsTqFqzSdj5FXYB2E.j8W0MW5ws2h2UfhwuHzJrsg.GhcMq92', 'CELEBRE', 'EDGAR', 'TUALLA', '100', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2006-08-07');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('029906', '$2y$10$H8k1m0swv2OGruTuHH85eucJF6//ApCowWl.VWgbIoGA63OuYifsW', 'EGUIA', 'RHUEL', 'MACALINDONG', '400', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2006-10-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('031307', '$2y$10$cLOKO0bdHCXwfLpyp3jQE.1wncKro3x9xAdNv4ShNZjTEyG3GbPpm', 'PAJUTAN', 'MELVIRG', 'ROXAS', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2007-03-07');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('031707', '$2y$10$Cq45Bogh.FbtQgbStMnB1.fSJ68Eh2BJChobc0a/rP6M9DgE./2gC', 'LIPIO', 'JOSEPHINE', 'ORBILLO', '321', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2007-07-10');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('031807', '$2y$10$UjvDIW2v7EfVPRvUhttjL.MSZQn.qQbyeJOurJlAm91EJmxxd6AWy', 'ROBLES', 'GLECY', 'VILLAMOR', '321', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2007-07-10');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('032007', '$2y$10$3zorDjbtdyXRHhsU9P.eMOCUDZUBBtUUe6ktIBvdw7qZTaSkjRrea', 'BAGO', 'MA. VICTORIA', 'DE LEON', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2007-08-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('032407', '$2y$10$qwsNr8/ezxdla8PWpPndQ.yq19Pk1tsMuizm6JP/2qdBT9G9SCYqC', 'BANNAGAO', 'LAWRENCE ARNEL', 'ACOSTA', '322', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2007-09-24');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('032608', '$2y$10$kUfiZvtoYj6KqLYXt76vmeihBxb5SicMbNsnMI0qKTp3X6ELuJEoq', 'RUAR', 'FLORDELIZA', 'BISCO', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2008-02-18');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('032808', '$2y$10$SBs/H4RHgWr03933mzeFjO14mBzA/ym4ULlNRe9fQ7nL44FOU0DbO', 'ASINAS', 'MARLON', 'DURAN', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2008-02-26');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('034409', '$2y$10$7beGpDOpWbZUGd5QLdVAcuV5Ejj0y63Rj6R0hSJvyBsCRFcDX497u', 'LUZANO', 'ROMEL', 'BUGARIN', '351', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2009-04-27');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('034709', '$2y$10$QRbSnBWU0CgC3.D/6zHiNOwwMD5uovMFG0xZmSAt7R8pix/LZzK5e', 'ITLIONG', 'MARK GIL', 'ESTIBAL', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2009-06-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('035009', '$2y$10$6xbTYUZgiiF492KzFXpgZuawgIYO4qE1ms107/XW.ga6AphIs2Y7u', 'PANOPIO', 'MELANIE', 'REFIL', '700', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2009-08-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('035109', '$2y$10$69FF.Q68cKmrpDG5G92iGeRwuBTzNqD2EtzDHZNgDXudt0wuufJi.', 'UDARBE', 'MARCEL', 'SALTING', '300', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2009-09-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('035610', '$2y$10$PTHlOApIfoHxO8sJUUD6n.mutjnw3mjSANbGSxHmOjZeRcKcwovk6', 'NAQUILA', 'STEMARK', 'PANA', '321', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-02-03');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('035910', '$2y$10$qOVZxafubLiLhPdPABxaD.TbHWS.1YxrFCMtKbsqyQOD6U8rN3Fn.', 'SAYSON', 'MICHAEL', 'AGATO', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2010-05-05');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('036611', '$2y$10$PAcuJwmIFd4FdSjO5L2dfe1qKWLj1RSy6RriteTHeG8ArD9a6uMNy', 'HIFE', 'MARIA ROWENA', 'REYES', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-02-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('039612', '$2y$10$ErEGIMiYqys9XM6bXFqAnOk7Wfw53ix9.CJU4AdujwjJMNADYSYdy', 'LEYRAN', 'AILENE', 'ROMASANTA', '140', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2012-07-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('039912', '$2y$10$uXnvqeSORyOMLTy8O9qOAOV24261/FbQEYFWdohRDDXAV6AaKl33W', 'BORJA', 'ALFER MARCOS', 'CRISPINO', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2012-11-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('040113', '$2y$10$lk.6iV0WzAEQk6h.NEqpreaZXCdizsbE3DUHQtlcJBHLmeraPXkT.', 'MANARIN', 'JEFFEL KURT', 'NAN', '700', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-03-25');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('040613', '$2y$10$8E0Cak.di.33hyeXNf2DEuf1qZXliKFJM9soLBSziv/O5jmVq.Dn.', 'OLIQUINO', 'ROBERTO', 'PERAS', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2013-07-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('041014', '$2y$10$Ntx/rlpj7Dh81JZ108rJe.y1tfXKBvvx5zl42CgGK2bXCeOVB1EO6', 'EVANGELISTA', 'JESSA', 'APOR', '140', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-09-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('041214', '$2y$10$7bMPp6i37qgibhkvvxs.TuqU./9xOGiVn0.WPoioeRVXhOFKylo6q', 'MOLINA', 'MARIA PAMELA', 'CAIRO', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-03-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('042214', '$2y$10$PrmRGc4gNZZzDakTt.LQ4u4liglyYgXvBV3Vfnc0iYDc/FwYGqgLq', 'SAQUIBAL', 'ARIES VANN', 'RETUYA', '600', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2014-06-23');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('042515', '$2y$10$hiHIXSQT6SjHrnpBkuqIke7UX3XmlzuNLczlL59yCXNB31t0Gsi4K', 'EBARITA', 'JUN ALBERT', 'CORILLA', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-02-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('042615', '$2y$10$/Bfbauq7IHbu0KRlKxS3ie6SSkueNm.mZnxPsO1r5Ji/G/F0gz8xC', 'HERNANDEZ', 'CHRISTIAN', 'CAO', '332', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-02-18');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('042715', '$2y$10$8nUaKcQm.WjpMifvb97i/Ovp9XzWZ9/MpPi0KViJoXs0qAO/CFaF2', 'RAVANA', 'GAYLORD', 'CAMACHO', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-03-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('042815', '$2y$10$EhvLvabYJ2mxtwOTBudC/elaja4pgIDHQrGBhElyFkXBjDaSBouV6', 'GARANO', 'MARLON', 'SALVADOR', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-03-05');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('043815', '$2y$10$N174FlEGPsP46y59ENoaTuhMUu5j1NCxe6Q2knbsztntznSQQVHVO', 'MANINGO', 'ALEJANDRO', 'CABINGAS', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-10-05');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('043915', '$2y$10$1MJjwsekTzaPMDp3JdoKrOCdzA57LWCOMvox.6ba..958RBXgu7C2', 'ROXAS JR.', 'FELICITO', 'DIZON', '332', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-10-12');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('044216', '$2y$10$RbYA0z2tRsPo/PH1OKMRguS8KTEhNePtkr6g0P0fktEyDQvAnDY2C', 'ZABALA', 'KENNETH', 'TORRES', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045016', '$2y$10$P/UgqB8ZmDEArtWYIO.ezend7EJGtnyT62IzmOwItjzccntlPzyz2', 'CERRUDO', 'CHARMAINE', 'LAGMAN', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-06-20');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045116', '$2y$10$jwwEQt8paWSydEYqls74/uGHsmeq5W2E1Ri7fa7tiSkwZOM8ydqE6', 'CRUZ', 'ELEANORE', 'BANGGA', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-06-22');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045216', '$2y$10$owgRdNp6m.YjS./DZyE3Luc.2899aLCAbwhSYb56CrGAi6cFYqB4W', 'CELIS', 'MARIDEL', 'VALENCIA', '322', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-07-12');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045316', '$2y$10$XI15Lf6mpaQ1T/fKKDKr.e0vLmfco3bDF3tlIYVPgpm5w7FE0f0Nu', 'DE JESUS', 'FERLYN', 'BALICUATRO', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-07-14');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045416', '$2y$10$Lyn1upllw8lh24QEJrCzcOsnQnIrD1l26IIZqMcqQ109J/82Ey78e', 'AMION', 'GLACESARY', 'EMBILE', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-09-13');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('045516', '$2y$10$eknjTb81/MATdrLiqFjg8.wO/huXFo33x2VY4Qs687iFivRC3BsrK', 'PEREZ', 'MARCH ROSE SHELL', 'PANES', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-09-13');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046016', '$2y$10$n6tWZcsMLC1chTfqvzDdUezKqAHouNN2yT7IikwAZKHqO5D1IR.X2', 'JAMORALIN', 'ANELE', 'BAUTISTA', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-11-21');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046217', '$2y$10$dxwKlok4cnwZohAY6/PorurjWndYqs8hZ5DFDRCwdHm8yrQcWRUx6', 'RED', 'REYNANTE', 'PETILLA', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-01-16');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046417', '$2y$10$UkoP4Yv5Ek4tDo6xB5EBV.6xBdp/upR4Kbp7sl7/gS9notivVHwBi', 'ABAWAG', 'REINHARD CIRE', 'ESCOBAR', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-03-13');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046617', '$2y$10$uIowP5ZBPtYY6G3I9OEGFO/D2IetOrlffg1ZcL6At9fH1C8lo7MFS', 'MANDAL', 'MV LEBERTY', 'PAMOLERAS', '100', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-03-13');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046717', '$2y$10$lwPdOcB4FmuU93iKyZ47Oez.yYmLrEPfod4JibeDFFZWp1AnSdIl6', 'TOBIAS', 'EGAN', 'ODICTA', '600', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-03-23');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('046817', '$2y$10$0l/phzEgbeXXDyVq3ymApezNRU4ldXZGVIkZ6ofoluKRQX3kZxbuK', 'MALLETE', 'MONICA', 'BALDERAS', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-04-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047017', '$2y$10$29ufEi8tLe4bHsoZw1mqnOKkdNyeghgaOAG9SV80INbQ1UOReDr9W', 'RIVERA', 'MARK ANGELO', 'PENANO', '150', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-04-17');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047117', '$2y$10$cJj/zqCTi5ofjhGHuz0HUOFCkkith8kvSC9ZlptpvfM774uaOdoRW', 'CRISTAL JR.', 'CIPRIANO', 'DILIG', '332', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-05-29');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047317', '$2y$10$B7fTFFvocGvHs9HSpuMuAOl/AwM7QZbYCx43W/V2xKE.k64iRUy5a', 'ABALIN JR.', 'REYNALDO', 'LUCERO', '352', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-07-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047417', '$2y$10$xgT3IIMdE/QDhbDynxmk9uik86JMu7.HTI6Z71P80HtEqlFn5oG5O', 'BORBANO', 'LIEZEL', 'GARCIA', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-07-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047517', '$2y$10$YGHQVXZePDewoIjBVDNp9uUKjNUwR7CHGWqws3/KJYRmuLJtSj8oK', 'DINGLE', 'MAYLYN', 'ARABACA', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-08-14');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047617', '$2y$10$eIYhgBZK/aRiu2lmEnvHjuINpkQNP8SdqbV6LG2Ut/u.Rs6M8hI4K', 'CASUGA', 'MAY ANN', 'OBIANO', '331', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-08-14');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('047817', '$2y$10$8mKXZofku0NGAHvZr1dBFeoRDejHgfQm7ihX6Jw8fIcvCcwL7Nkt6', 'VILLAHERMOSA', 'JASMIN', 'REYES', '120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-11-22');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048018', '$2y$10$NKTCEC7wEy/N2pOXtckFweOJYrRZroGIpbfRKYCH.F2S.CTsYA1zq', 'AGO', 'OLIVE COLEEN', 'DONATO', '400', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-02-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048118', '$2y$10$e1OnBv9cVhLtA1ngzFP5l.yvv.QwfJOq3wQYAJBOi4ner.n8gb3YW', 'AGUILON', 'NOEL', 'DE LOS REYES', '321', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-02-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048218', '$2y$10$XyxYwvFENIpD9L95kxSZe.qZK0E2Fknn8soSJg7pdCrpN3ZngpbNq', 'BATALON', 'EDGAR', 'INSO', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-02-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048318', '$2y$10$6EwkDzqgCs7j.uoF2GYBm.NuCmK8KwMvuOrI8Y.e5rQO4/bEz2B9W', 'PANGANTIHON', 'MARYJANE', 'ALLIC', '230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-02-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048618', '$2y$10$ipH10e2wcGSIe5cg9GOzR.fmkDZwnlu.WCZ4rFkV6N6G4eBsGS/EK', 'MUENA', 'ROLANDO JR.', 'BUENAVISTA', '140', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-04-10');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048818', '$2y$10$KErrHxrx9oDWYAZLbhofKOlwv94r9.xdMgVZSh/S4c/rj6gFXIa1m', 'LEGACION', 'MARIE VIANNEY', 'LIBRANDO', '600', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-06-11');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('048918', '$2y$10$rDwQQXB9qB67bnXgfISSJesfmWyWA8X9l/YCqRTd6jRo0XGjlp9vC', 'MANALO', 'RONALD', 'CUENCA', '130', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-06-21');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('049018', '$2y$10$KkRecWuBUmA6nVJlfx83pONWa6gk9VeUfT9Us.JCLYa1cM8QSAu8K', 'FELIZARDO', 'ALVIN', 'ABOT', '352', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-06-21');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('049118', '$2y$10$YTLwzqZGZbonQkr9vovftOR2H1TJcGdHsurpW7YxBWcSkO1sgjS9u', 'MANGONON', 'LEA EDELMA', 'STA MARIA', '500', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-07-09');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('049418', '$2y$10$uXmheEgX9PWLSQxTd3A0v.KcIO1RZQUBjXeq9miKkr0hz/rGNM.8e', 'HERNANDEZ', 'JENNIFER', 'SANCHEZ', '500', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-11-16');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('049719', '$2y$10$aROl0MShRvK/pJuz0EsZ8exF69eiU/POlwBMpHdAjYmW.uqxsbG9K', 'OLLET', 'CATHLEEN', 'CUEVA', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-07-18');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('049919', '$2y$10$tLVcjrJdW5ak5GWlvT7/H.a.vmUYIjkeNVqR5pk7qJ2XTwiY9ym7a', 'HONRADE', 'RICHARD ANTHONY', 'PONAN', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-09-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050019', '$2y$10$UK.U1ot0MmNz/SydvGwLyOmh4hFS70/OtH0ZmybRgrOpXEzbHw0gO', 'GO,  JR.', 'JOAQUIN', 'LIM', '211', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-09-23');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050119', '$2y$10$vwYZJ7uv6jHqzSXtgdptMOH3aiSlo0EMEfHjKUZWRAPkoqv4ET3Mu', 'GALIPOSO', 'ROEL', 'PONTRIAS', '211', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-14');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050219', '$2y$10$K92jJGMZE45OrKHF74rIiOyDxHZH7Rl8GhtPUWp3k9eXL/0qMEKvO', 'ONG', 'SOCORRO', 'ROPELOS', '500', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-15');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050419', '$2y$10$7oxY.mc8i52AQ2UX.i.Iquld3fRR2/vO7dj.izXSdte5klSCkoMtK', 'LIBED', 'ARNOLD', 'NOVAL', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-10-14');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050519', '$2y$10$/O59ko.kjGbPXtuiB0lhhO9twli1KWh1zF1FFWkanycyk9gvW5tue', 'MARCELO', 'ANNA LIZZA', 'ARGANA', '700', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-12-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050620', '$2y$10$pl0Ss1mzCxgWXcWR7ynKOOS9US.Pd8qmn7qVqG4J/zlCpcXKMINbC', 'BREVA', 'JENNETTE', 'GAN', '130', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-01-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050720', '$2y$10$VF4Po..3tdmil/SSbgGsUezvUTQwOGNcEnzy8y6CMV8f9Y/C6Yzrm', 'ROGEL', 'CHRISTIAN', 'PADOC', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-01-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050820', '$2y$10$lsgj61NuL/.WO9KqJq/hIO8FWUDMn6kX2AKWkzWLEYC5ffjEXlmjq', 'VARGAS', 'VICTOR JOSEPH', 'MAG-ISA', '400', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-01-06');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('050920', '$2y$10$kDnyorJZGHDkwLpwSjdvsOev6nsng9/g/QXZcTo.VQL3k7GKgSNC.', 'SALE', 'JOENARD', 'CUSTODIO', '340', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-02-03');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051120', '$2y$10$6.lvozXTmOFFkdfz37CAA.hny8wobSoNBmJqYd20s3gDGDOuwUoA.', 'CARMEN', 'JENEROSE', 'EMA', '210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-02');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051320', '$2y$10$U9dUwOD8c7EjHHkYc.QFwOTWQtr6wtS9QEQ4ZhKES.ET.mMSpVJFu', 'CARIAGA', 'EVANGELINE', 'SUING', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-16');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051420', '$2y$10$ylQ34he2pOQxkTKJxXaIKuvlO.9Srw1Kqt4gxyyHx0ojeXfoSGtcm', 'DE GUZMAN', 'ALVIN', 'OLILA', '351', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051520', '$2y$10$iaj8fvHOsS2aFE57cp4OpO4/b0WqmY/Myuppe0CapoUo/SGIlkAqi', 'FLORES JR', 'PRISCILO FABIAN', 'REYES DE LOS', '352', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-09-01');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051620', '$2y$10$.0/OKH/G3T4aXzZyEnGGhOA2fY624mFG3SWJAD.gzX1gy8XNAve..', 'PULLON', 'JAN ADRIAN', 'DELA CRUZ', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-10-28');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051720', '$2y$10$uH314CN1Wf5sVJNCI7LdX.TxvAgomcqAfTg/2cPMr1OVgFNzrfBsK', 'VILLANUEVA', 'ALLEN', 'DEQUINA', '353', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-10-28');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051821', '$2y$10$qIgaC4KoJZQPHGMzBUpFO.wRfJ0AklYU0tvaql8FVtq14gEprYkoS', 'BALLESTEROS', 'MARTHA JORGIANNA', 'LUCES', '220', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-01-04');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('051921', '$2y$10$/29SHCarPORIEC8d3dFMgemPiU4UY2QY.MrqjEvrsmdfmIJd3D2we', 'CARANGUIAN', 'ARNOLD', 'DAYAG', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-15');
INSERT INTO `employees` (`empcode`, `password`, `lname`, `fname`, `mname`, `deptcode`, `supervisor`, `depthead`, `secthead`, `divhead`, `is_hr`, `is_payroll`, `is_audit`, `hiredate`) VALUES ('052021', '$2y$10$1pbbr8V4hQTQdxpMsPPoHOFwzITB4.6V1gHf1XLwf.fPXjMqSrEq.', 'ONG', 'JOVITO', 'CATAHAY', '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-02-15');


#
# TABLE STRUCTURE FOR: leaves
#

DROP TABLE IF EXISTS `leaves`;

CREATE TABLE `leaves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empcode` varchar(6) NOT NULL,
  `name` varchar(65) NOT NULL,
  `date_filed` date NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `pay` varchar(65) NOT NULL,
  `type` varchar(65) NOT NULL,
  `reason` text NOT NULL,
  `recommended_by` varchar(6) DEFAULT NULL,
  `approved_by` varchar(6) DEFAULT NULL,
  `rec_status` tinyint(1) NOT NULL,
  `appr_status` tinyint(1) NOT NULL,
  `status` varchar(10) DEFAULT 'PENDING',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: overtimes
#

DROP TABLE IF EXISTS `overtimes`;

CREATE TABLE `overtimes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empcode` varchar(10) NOT NULL,
  `deptcode` varchar(10) NOT NULL,
  `date_filed` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `hrs` double NOT NULL,
  `reason` text NOT NULL,
  `rec_by` varchar(10) DEFAULT NULL,
  `appr_by` varchar(10) DEFAULT NULL,
  `rec_status` bit(1) DEFAULT NULL,
  `appr_status` bit(1) DEFAULT NULL,
  `status` varchar(10) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `appr_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: schedule
#

DROP TABLE IF EXISTS `schedule`;

CREATE TABLE `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp` varchar(10) NOT NULL,
  `date_filed` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `purpose` varchar(50) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `from_time` varchar(50) NOT NULL,
  `to_time` varchar(50) NOT NULL,
  `reason` text NOT NULL,
  `reliever` varchar(50) NOT NULL,
  `approver` varchar(10) NOT NULL,
  `personnel` varchar(10) DEFAULT NULL,
  `approved` tinyint(1) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'PENDING',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: trail
#

DROP TABLE IF EXISTS `trail`;

CREATE TABLE `trail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `request_id` int(10) NOT NULL,
  `approver_id` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

SET foreign_key_checks = 1;
